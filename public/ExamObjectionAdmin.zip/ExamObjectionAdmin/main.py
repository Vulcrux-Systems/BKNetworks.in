from src.router.exam_objections_admin.Examquestionrouter import router as exam_objections_question
from src.router.exam_objections_admin.exam_router import  exam_objection_router


app.include_router(exam_objections_question)
app.include_router(exam_objection_router)