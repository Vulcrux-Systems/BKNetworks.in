from typing import Optional
from pydantic import BaseModel

class SaveExamRequest(BaseModel):
    exam_id: Optional[int] = None
    exam_title: str
    exam_date: str
    no_of_questions: int
    total_answer_options: int
    objection_raise_start_time: Optional[str] = None
    objection_raise_end_time: Optional[str] = None
    xobjection_start_time: Optional[str] = None
    xobjection_end_time: Optional[str] = None
    active: str


class ExamResponse(BaseModel):
    exam_id: int
    exam_title: Optional[str] = None
    exam_date: Optional[str] = None
    no_of_questions: Optional[int] = None
    total_answer_options: Optional[int] = None
    objection_raise_start_time: Optional[str] = None
    objection_raise_end_time: Optional[str] = None
    xobjection_start_time: Optional[str] = None
    xobjection_end_time: Optional[str] = None
    objection_time: Optional[str] = None
    xobjection_time: Optional[str] = None
    question_booklet_url: Optional[str] = None
    answer_booklet_url: Optional[str] = None
    userid: Optional[str] = None
    entry_date: Optional[str] = None
    user_details: Optional[str] = None
    row_id: Optional[str] = None
    active: Optional[str] = None
    active_value: Optional[str] = None 