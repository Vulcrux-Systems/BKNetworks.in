from pydantic import BaseModel
from typing import Optional


class UpdateQuestionRequest(BaseModel):
    exam_id:      int
    question_id:  int
    question:     str
    option1:      str
    option2:      str
    option3:      str
    option4:      str
    correct:      str          
    xobj_allowed: str       
    xobj_answer:  Optional[str] = ""
    username:     str
    
class ObjectionsReportRequest(BaseModel):
    exam_id:  int
    order_by: Optional[str] = "Q"   
    obj_type: Optional[str] = "O"   
 