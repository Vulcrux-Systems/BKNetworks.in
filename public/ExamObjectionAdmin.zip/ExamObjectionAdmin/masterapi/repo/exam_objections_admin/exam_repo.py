from sqlalchemy import text
import os
import io
import pandas as pd
import shutil
from datetime import datetime
from fastapi import HTTPException, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession
from src.request.exam_objections_admin.exam_request import SaveExamRequest

class ExamRepository:
    def __init__(
        self,
        db: AsyncSession
    ):
        self.db = db
    async def save_exam(
        self,
        payload: SaveExamRequest,
        username: str,
        quetion_booklet_file: UploadFile | None = None,
        answer_booklet_file: UploadFile | None = None,
    ):
        upload_dir = "uploads/exam_objections"
        os.makedirs(upload_dir, exist_ok=True)
        exam_date = datetime.strptime(payload.exam_date, "%Y-%m-%d").date()
        def parse_dt(val):
            return datetime.strptime(val, "%Y-%m-%dT%H:%M") if val else None
        objection_raise_start_time = parse_dt(payload.objection_raise_start_time)
        objection_raise_end_time   = parse_dt(payload.objection_raise_end_time)
        xobjection_start_time      = parse_dt(payload.xobjection_start_time)
        xobjection_end_time        = parse_dt(payload.xobjection_end_time)
        is_update      = payload.exam_id not in [0, "0", "", None]
        existing_exam_id = payload.exam_id if is_update else None
        has_question_file = bool(quetion_booklet_file and quetion_booklet_file.filename)
        has_answer_file   = bool(answer_booklet_file and answer_booklet_file.filename)
        q_filename_for_proc = (
            f"{existing_exam_id}_questions.pdf"
            if (is_update and has_question_file)
            else None
        )
        a_filename_for_proc = (
            f"{existing_exam_id}_answer.pdf"
            if (is_update and has_answer_file)
            else None
        )
        query = text("""
            SELECT *
            FROM pnb_ishico.proc_exam_addupdate(
                :p_exam_id,
                :p_exam_title,
                :p_exam_date,
                :p_no_of_questions,
                :p_total_answer_options,
                :p_objection_raise_start_time,
                :p_objection_raise_end_time,
                :p_xobjection_start_time,
                :p_xobjection_end_time,
                :p_ques_booklt,
                :p_ans_booklt,
                :p_active,
                :p_userid
            )
        """)
        params = {
            "p_exam_id":                    existing_exam_id,
            "p_exam_title":                 payload.exam_title,
            "p_exam_date":                  exam_date,
            "p_no_of_questions":            int(payload.no_of_questions) if payload.no_of_questions else None,
            "p_total_answer_options":       int(payload.total_answer_options) if payload.total_answer_options else None,
            "p_objection_raise_start_time": objection_raise_start_time,
            "p_objection_raise_end_time":   objection_raise_end_time,
            "p_xobjection_start_time":      xobjection_start_time,
            "p_xobjection_end_time":        xobjection_end_time,
            "p_ques_booklt":                q_filename_for_proc,
            "p_ans_booklt":                 a_filename_for_proc,
            "p_active":                     payload.active,
            "p_userid":                     username,
        }

        result = await self.db.execute(query, params)
        row = result.mappings().first()
        if row["outcome"] != "SUCCESS":
            await self.db.rollback()
            return {"success": False, "message": row["message"]}
        exam_id = row["p_out_examid"]
        if has_question_file:
            q_path = os.path.join(upload_dir, f"{exam_id}_questions.pdf")
            with open(q_path, "wb") as buffer:
                shutil.copyfileobj(quetion_booklet_file.file, buffer)
        if has_answer_file:
            a_path = os.path.join(upload_dir, f"{exam_id}_answer.pdf")
            with open(a_path, "wb") as buffer:
                shutil.copyfileobj(answer_booklet_file.file, buffer)
        if not is_update and (has_question_file or has_answer_file):
            await self.db.execute(
                text("""
                    UPDATE pnb_ishico.m_phhc_exam
                    SET
                        ques_boolt_file = CASE
                            WHEN :set_question THEN :question_filename
                            ELSE ques_boolt_file
                        END,
                        ans_boolt_file = CASE
                            WHEN :set_answer THEN :answer_filename
                            ELSE ans_boolt_file
                        END
                    WHERE exam_id = :exam_id
                """),
                {
                    "set_question":      has_question_file,
                    "question_filename": f"{exam_id}_questions.pdf",
                    "set_answer":        has_answer_file,
                    "answer_filename":   f"{exam_id}_answer.pdf",
                    "exam_id":           exam_id,
                }
            )
        await self.db.commit()
        return {"success": True, "message": row["message"]}

    async def get_all_exams(self):
        query = text("""
            SELECT
                exam_id,
                exam_title,
                no_of_questions,
                total_answer_options,
                ques_boolt_file,
                ans_boolt_file,
                userid,
                active,

                TO_CHAR(
                    exam_date,
                    'YYYY-MM-DD'
                ) AS exam_date,

                TO_CHAR(
                    objection_raise_start_time,
                    'YYYY-MM-DD"T"HH24:MI'
                ) AS objection_raise_start_time,

                TO_CHAR(
                    objection_raise_end_time,
                    'YYYY-MM-DD"T"HH24:MI'
                ) AS objection_raise_end_time,

                TO_CHAR(
                    xobjection_start_time,
                    'YYYY-MM-DD"T"HH24:MI'
                ) AS xobjection_start_time,

                TO_CHAR(
                    xobjection_end_time,
                    'YYYY-MM-DD"T"HH24:MI'
                ) AS xobjection_end_time,

                TO_CHAR(
                    entry_date,
                    'DD-MON-YY HH24:MI'
                ) AS entry_date

            FROM pnb_ishico.m_phhc_exam
            ORDER BY exam_id
        """)
        result = await self.db.execute(query)
        rows = result.mappings().all()
        final_result = []
        for row in rows:
            active_raw = row["active"]
            objection_time = ""
            if (
                row["objection_raise_start_time"]
                and row["objection_raise_end_time"]
            ):
                objection_time = (
                    f"{row['objection_raise_start_time']} "
                    f"to "
                    f"{row['objection_raise_end_time']}"
                )
            xobjection_time = ""
            if (
                row["xobjection_start_time"]
                and row["xobjection_end_time"]
            ):
                xobjection_time = (
                    f"{row['xobjection_start_time']} "
                    f"to "
                    f"{row['xobjection_end_time']}"
                )
            user_details = row["entry_date"]
            if (
                row["userid"]
                and row["entry_date"]
            ):
                user_details = (
                    f"{row['userid']}/"
                    f"{row['entry_date']}"
                )
            final_result.append({
                "exam_id": row["exam_id"],
                "exam_title": row["exam_title"],
                "exam_date": row["exam_date"],
                "no_of_questions": row["no_of_questions"],
                "total_answer_options":row["total_answer_options"],
                "objection_raise_start_time":row["objection_raise_start_time"],
                "objection_raise_end_time": row["objection_raise_end_time"],
                "xobjection_start_time": row["xobjection_start_time"],
                "xobjection_end_time":  row["xobjection_end_time"],
                "objection_time":  objection_time,
                "xobjection_time": xobjection_time,
                "question_booklet_url": row["ques_boolt_file"],
                "answer_booklet_url": row["ans_boolt_file"],
                "userid": row["userid"],
                "entry_date":row["entry_date"],
                "user_details": user_details,
                "active":
                    "Yes"
                    if active_raw == "Y"
                    else "No",
                "active_value":
                    active_raw,
            })
        return final_result

    async def delete_exam(
        self,
        exam_id: int,
        username: str
    ):
        file_query = text("""
            SELECT
                ques_boolt_file,
                ans_boolt_file
            FROM pnb_ishico.m_phhc_exam
            WHERE exam_id = :exam_id
        """)
        file_result = await self.db.execute(
            file_query,
            {
                "exam_id": exam_id
            }
        )
        file_row = file_result.mappings().first()
        query = text("""
            SELECT *
            FROM pnb_ishico.proc_exam_delete(
                :p_exam_id,
                :p_userid
            )
        """)
        result = await self.db.execute(
            query,
            {
                "p_exam_id": exam_id,
                "p_userid": username
            }
        )
        row = result.mappings().first()
        await self.db.commit()
        if (
            row["outcome"] == "SUCCESS"
            and file_row
        ):
            upload_dir = "uploads/exam_objections"
            backup_dir = "uploads/exam_objections/exam_objections_deleted"
            os.makedirs(backup_dir, exist_ok=True)
            if file_row["ques_boolt_file"]:
                qfile = os.path.join( upload_dir, file_row["ques_boolt_file"] )
                if os.path.exists(qfile):
                    shutil.move( qfile, os.path.join(backup_dir,file_row["ques_boolt_file"] )
                    )
            if file_row["ans_boolt_file"]:
                afile = os.path.join( upload_dir,file_row["ans_boolt_file"] )
                if os.path.exists(afile):
                    shutil.move( afile, os.path.join( backup_dir, file_row["ans_boolt_file"] ))
        return {
            "success":
                row["outcome"] == "SUCCESS",
            "message":
                row["message"]
        }    
    async def upload_candidates(
        self,
        exam_id: int,
        username: str,
        file_contents: bytes,
        filename: str,
    ):
        if not filename.endswith((".xlsx", ".xls")):
            raise HTTPException(
                status_code=400,
                detail="Only Excel files (.xlsx, .xls) are allowed"
            )
        try:
            df = pd.read_excel(io.BytesIO(file_contents))
            df.columns = df.columns.str.strip().str.upper()
            required = {"ROLL_NO", "NAME", "MOBILE"}
            missing  = required - set(df.columns)
            if missing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Missing columns in Excel: {', '.join(missing)}"
                )
            df = df.dropna(subset=["ROLL_NO", "NAME", "MOBILE"])
            if df.empty:
                raise HTTPException(
                    status_code=400,
                    detail="No valid data found in Excel file"
                )
            await self.db.execute(
                text("""
                    DELETE FROM pnb_ishico.t_phhc_exam_obj_candidate
                    WHERE "EXAM_ID" = :exam_id
                """),
                {"exam_id": exam_id}
            )
            inserted = 0
            skipped  = 0
            errors   = []
            for index, row in df.iterrows():
                try:
                    await self.db.execute(
                        text("""
                            INSERT INTO pnb_ishico.t_phhc_exam_obj_candidate (
                                "EXAM_ID",
                                "ROLL_NO",
                                "NAME",
                                "MOBILE",
                                "USER_CREATED_ON",
                                "USER_CREATED_BY"
                            )
                            VALUES (
                                :exam_id,
                                :roll_no,
                                :name,
                                :mobile,
                                CURRENT_DATE,
                                :username
                            )
                        """),
                        {
                            "exam_id":  exam_id,
                            "roll_no":  str(row["ROLL_NO"]).strip(),
                            "name":     str(row["NAME"]).strip(),
                            "mobile":   str(row["MOBILE"]).strip(),
                            "username": username,
                        }
                    )
                    inserted += 1
                except Exception as e:
                    skipped += 1
                    errors.append(f"Row {index + 2}: {str(e)}")
            await self.db.commit()
            return {
                "success":  True,
                "message":  f"{inserted} candidates inserted, {skipped} skipped.",
                "inserted": inserted,
                "skipped":  skipped,
                "errors":   errors,
            }

        except HTTPException:
            raise
        except Exception as e:
            await self.db.rollback()
            raise HTTPException(status_code=500, detail=str(e))


    async def get_candidates(
        self,
        exam_id: int,
    ):
        query = text("""
            SELECT
                "ROLL_NO"  AS roll_no,
                "NAME"     AS name,
                "MOBILE"   AS mobile
            FROM pnb_ishico.t_phhc_exam_obj_candidate
            WHERE "EXAM_ID" = :exam_id
            ORDER BY "ROLL_NO"
        """)
 
        result = await self.db.execute(query, {"exam_id": exam_id})
        rows   = result.mappings().all()
        return [
            {
                "roll_no": row["roll_no"],
                "name":    row["name"],
                "mobile":  row["mobile"],
            }
            for row in rows
        ]