from sqlalchemy import text
from datetime import datetime


class ExamQuestionRepo:

    def __init__(self, db):
        self.db = db

    async def get_exams(self):
        query = text("""
            SELECT exam_id, exam_title
            FROM pnb_ishico.M_PHHC_EXAM
            WHERE active = 'Y'
            ORDER BY exam_id
        """)
        result = await self.db.execute(query)
        rows = result.mappings().all()
        return [{"exam_id": r["exam_id"], "exam_title": r["exam_title"]} for r in rows]

    async def get_exam_by_id(self, exam_id: int) -> dict | None:
        query = text("""
            SELECT exam_id, exam_title, exam_date, no_of_questions
            FROM pnb_ishico.M_PHHC_EXAM
            WHERE exam_id = :exam_id
        """)
        result = await self.db.execute(query, {"exam_id": exam_id})
        row = result.mappings().first()
        
        return dict(row) if row else None

    async def get_questions_list(self, exam_id: int):
        query = text("""
            SELECT "QUESTION_NO" as question_no, 
                "QUESTION_STATEMENT" as                 question_statement
            FROM pnb_ishico.m_phhc_exam_questions
            WHERE "EXAM_ID" = :exam_id
            ORDER BY QUESTION_NO
        """)
        result = await self.db.execute(query, {"exam_id": exam_id})
        rows = result.mappings().all()
        return [
            {
                "question_no":        r["question_no"],
                "question_statement": r["question_statement"]
            }
            for r in rows
        ]

    async def get_question_detail(self, exam_id: int, question_id: int):

        if question_id == 0:
            return {"status": "True", "details": "New", "data": None}

        query = text("""
            SELECT
                "QUESTION_NO" as question_no,
                "EXAM_ID" as exam_id,
                "QUESTION_STATEMENT" as question_statement,
                "OPTION_1" as option_1,
                "OPTION_2" as option_2,
                "OPTION_3" as option_3,
                "OPTION_4" as option_4,
                "CORRECT_OPTION" as correct_option,
                "XOBJ_ALLOWED" as xobj_allowed,
                "XOBJ_ANSWER_OPTION" as xobj_answer_option
            FROM pnb_ishico.m_phhc_exam_questions
            WHERE "EXAM_ID"    = :exam_id
              AND "QUESTION_NO" = :question_no
            LIMIT 1
        """)

        result = await self.db.execute(query, {
            "exam_id":     exam_id,
            "question_no": question_id
        })

        row = result.mappings().first()

        if not row:
            return {"status": "False", "details": "Not Found", "data": None}

        return {
            "status":  "True",
            "details": "Data Fetch Successfully",
            "data": {
                "QUESTION_NO":        row["question_no"],
                "EXAM_ID":            row["exam_id"],
                "QUESTION_STATEMENT": row["question_statement"],
                "OPTION_1":           row["option_1"],
                "OPTION_2":           row["option_2"],
                "OPTION_3":           row["option_3"],
                "OPTION_4":           row["option_4"],
                "CORRECT_OPTION":     row["correct_option"],
                "XOBJ_ALLOWED":       row["xobj_allowed"],
                "XOBJ_ANSWER_OPTION": row["xobj_answer_option"],
            }
        }

    async def update_question(
        self,
        exam_id:      int,
        question_id:  int,
        question:     str,
        option1:      str,
        option2:      str,
        option3:      str,
        option4:      str,
        correct:      str,
        xobj_allowed: str,
        xobj_answer:  str,
        username:     str,
    ):

        if not all([question, option1, option2, option3, option4, correct, exam_id]):
            return {"status": "FAIL", "message": "All fields are mandatory"}

        try:
            if not xobj_answer or str(xobj_answer).strip() == '':
                xobj_answer = None
                
            query = text("""
                UPDATE pnb_ishico.m_phhc_exam_questions
                SET
                    "QUESTION_STATEMENT" = :question,
                    "OPTION_1"           = :option1,
                    "OPTION_2"           = :option2,
                    "OPTION_3"          = :option3,
                    "OPTION_4"          = :option4,
                    "CORRECT_OPTION"     = :correct,
                    "USERID"            = :username,
                    "ENTRY_DATE"        = CURRENT_TIMESTAMP,
                    "XOBJ_ALLOWED"       = :xobj_allowed,
                    "XOBJ_ANSWER_OPTION" = :xobj_answer
                WHERE
                    "QUESTION_NO" = :question_id
                    AND "EXAM_ID" = :exam_id
            """)

            await self.db.execute(query, {
                "question":    question,
                "option1":     option1,
                "option2":     option2,
                "option3":     option3,
                "option4":     option4,
                "correct":     correct,
                "username":    username,
                "xobj_allowed": xobj_allowed,
                "xobj_answer": xobj_answer,
                "question_id": question_id,
                "exam_id":     exam_id,
            })

            await self.db.commit()

            return {
                "status":  "SUCCESS",
                "message": "Question Updated Successfully"
            }

        except Exception as e:
            await self.db.rollback()
            return {
                "status":  "FAIL",
                "message": f"Failed: {str(e)}"
            }
    
    async def get_questions_obj_list(
        self,
        exam_id: int,
        order_by: str = "Q",   
    ) -> list[dict]:
 
        if order_by == "O":
     
            query = text("""
                SELECT
                    "EXAM_ID" as EXAM_ID,
                    "QUESTION_NO" as QUESTION_NO,
                    "QUESTION_STATEMENT" as QUESTION_STATEMENT,
                    "OPTION_1" as OPTION_1,
                    "OPTION_2" as OPTION_2,
                    "OPTION_3" as OPTION_3,
                    "OPTION_4" as OPTION_4,
                    "CORRECT_OPTION" as CORRECT_OPTION
                FROM pnb_ishico.M_PHHC_EXAM_QUESTIONS t1
                WHERE "EXAM_ID" = :exam_id
                ORDER BY (
                    SELECT COUNT(*)
                    FROM pnb_ishico.T_PHHC_EXAM_OBJECTIONS t2
                    WHERE t1."QUESTION_NO" = t2."QUESTION_SR_NO"
                      AND t1."EXAM_ID"    = t2."EXAM_ID"
                ) DESC
            """)
        else:
            
            query = text("""
                SELECT
                    "EXAM_ID" as EXAM_ID,
                    "QUESTION_NO" as QUESTION_NO,
                    "QUESTION_STATEMENT" as QUESTION_STATEMENT,
                    "OPTION_1" as OPTION_1,
                    "OPTION_2" as OPTION_2,
                    "OPTION_3" as OPTION_3,
                    "OPTION_4" as OPTION_4,
                    "CORRECT_OPTION" as CORRECT_OPTION
                FROM pnb_ishico.M_PHHC_EXAM_QUESTIONS
                WHERE "EXAM_ID" = :exam_id
                ORDER BY "QUESTION_NO"
            """)
 
        result = await self.db.execute(query, {"exam_id": exam_id})
        return [dict(r) for r in result.mappings().all()]

    async def get_objections_grouped(
        self,
        exam_id: int,
        obj_type: str,   
    ) -> list[dict]:
   
        query = text("""
            SELECT
                QUESTION_SR_NO ,
                CANDIDATE_ANSWER,
                COUNT(*) AS CNT
            FROM (
                SELECT DISTINCT "ROLL_NO" as ROLL_NO, "QUESTION_SR_NO" as QUESTION_SR_NO, "CANDIDATE_ANSWER" as CANDIDATE_ANSWER
                FROM pnb_ishico.T_PHHC_EXAM_OBJECTIONS
                WHERE "EXAM_ID"      = :exam_id
                  AND "OBJ_OR_CROSS" = :obj_type
            ) t
            GROUP BY QUESTION_SR_NO, CANDIDATE_ANSWER
            ORDER BY QUESTION_SR_NO, CANDIDATE_ANSWER
        """)
        result = await self.db.execute(query, {
            "exam_id":  exam_id,
            "obj_type": obj_type,
        })
        return [dict(r) for r in result.mappings().all()]

    async def get_chart_data(
        self,
        exam_id: int,
        obj_type: str,   
    ) -> list[dict]:
        
        query = text("""
            SELECT "QUESTION_SR_NO" as QUESTION_SR_NO, COUNT(*) AS CNT
            FROM pnb_ishico.T_PHHC_EXAM_OBJECTIONS
            WHERE "EXAM_ID"      = :exam_id
              AND "OBJ_OR_CROSS" = :obj_type
            GROUP BY "QUESTION_SR_NO"
            ORDER BY CNT DESC
            LIMIT 30
        """)
        result = await self.db.execute(query, {
            "exam_id":  exam_id,
            "obj_type": obj_type,
        })
        rows = result.mappings().all()
 
        
        chart_data = []
        for row in rows:
            chart_data.append({
                "language": f"Q.No. {row['question_sr_no']}",
                "total":    row["cnt"],
                "color":    "#FF7F7F",
            })
 
        
        while len(chart_data) < 30:
            chart_data.append({"language": "", "total": 0, "color": "#FF7F7F"})
 
        return chart_data[:30]
