class ExamObjectionsService:

    def __init__(self, repo):
        self.repo = repo

   
    async def get_objections_report(
        self,
        exam_id: int,
        order_by: str,   
        obj_type: str,  
    ) -> dict:

        
        exam = await self.repo.get_exam_by_id(exam_id)
        if not exam:
            return {"success": False, "message": "Exam Details Not Found"}

        rep_type = "X-Objections" if obj_type == "X" else "Objections"

       
        questions = await self.repo.get_questions_obj_list(exam_id, order_by)

        
        objections_raw = await self.repo.get_objections_grouped(exam_id, obj_type)

        
        obj_map: dict[int, dict[int, int]] = {}
        for row in objections_raw:
            qno    = int(row["question_sr_no"])
            option = int(row["candidate_answer"])
            cnt    = int(row["cnt"])
            if cnt > 0:
                if qno not in obj_map:
                    obj_map[qno] = {}
                obj_map[qno][option] = cnt

       
        obj_grand_total  = 0
        obj_question_cnt = 0
        question_rows    = []

        for q in questions:
            question_no  = q["question_no"]
            correct_opt  = str(q.get("correct_option") or "")

            
            obj_cnt_a = obj_map.get(question_no, {}).get(1, 0)
            obj_cnt_b = obj_map.get(question_no, {}).get(2, 0)
            obj_cnt_c = obj_map.get(question_no, {}).get(3, 0)
            obj_cnt_d = obj_map.get(question_no, {}).get(4, 0)
            obj_cnt_e = obj_map.get(question_no, {}).get(8, 0)  

            total_obj = obj_cnt_a + obj_cnt_b + obj_cnt_c + obj_cnt_d + obj_cnt_e

            
            if total_obj > 0:
                obj_question_cnt += 1
                obj_grand_total  += total_obj

                
                question_rows.append({
                    "exam_id":            q["exam_id"],
                    "question_no":        question_no,
                    "question_statement": q["question_statement"],
                    "option_1":           q["option_1"],
                    "option_2":           q["option_2"],
                    "option_3":           q["option_3"],
                    "option_4":           q["option_4"],
                    "correct_option":     correct_opt,
                   
                    "option_e":           "Incorrect Question",
                    
                    "is_deleted":         correct_opt == "9",
                    "obj_cnt_a":          obj_cnt_a,
                    "obj_cnt_b":          obj_cnt_b,
                    "obj_cnt_c":          obj_cnt_c,
                    "obj_cnt_d":          obj_cnt_d,
                    "obj_cnt_e":          obj_cnt_e,
                    "total_obj":          total_obj,
                })

        return {
            "success":         True,
            "exam_id":         exam["exam_id"],
            "exam_title":      exam["exam_title"],
            "exam_date":       str(exam.get("exam_date") or ""),
            "rep_type":        rep_type,
            "obj_grand_total": obj_grand_total,
            "obj_question_cnt":obj_question_cnt,
            "questions":       question_rows,
        }

   
    async def get_chart_data(self, exam_id: int, obj_type: str) -> list[dict]:
        return await self.repo.get_chart_data(exam_id, obj_type)