import logging
import os
import io
import pandas as pd
from typing import List
from fastapi import (
    APIRouter,
    Depends,
    Form,
    HTTPException,
    Request,
    UploadFile,
    File,
)
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession
from src.repo.engine import get_db
from src.repo.exam_objections_admin.exam_repo import (
    ExamRepository,
)
from src.request.exam_objections_admin.exam_request import (
    ExamResponse,SaveExamRequest
)
class ExamRouter:
    def __init__(self):
        logging.basicConfig(
            level=logging.INFO,
            filename="src.log",
            filemode="a",
            format="%(asctime)s - %(levelname)s - %(message)s",
        )
        self.logger = logging.getLogger(
            "exam_objection_router"
        )
        self.router = APIRouter(
            prefix="/exam_objection",
            tags=["Exam Objection"]
        )
        self.router.add_api_route(
            "/delete_exam/{exam_id}",
            self.delete_exam,
            methods=["DELETE"],
            name="delete_exam",
        )
        self.router.add_api_route(
            "/exams",
            self.get_exam_list,
            methods=["GET"],
            response_model=List[ExamResponse],
            name="exam-list",
        )
        self.router.add_api_route(
            "/save-exam",
            self.save_exam,
            methods=["POST"],
            name="save_exam",
        )
        self.router.add_api_route(
            "/fetchDocs",
            self.serve_exam_file,
            methods=["GET"],          
            name="fetch_exam_docs",
        )
        self.router.add_api_route(
            "/upload_candidates",
            self.upload_candidates,
            methods=["POST"],
            name="upload_candidates",
        )
        self.router.add_api_route(
            "/candidates",
            self.get_candidates,
            methods=["GET"],
            name="get_candidates",
        )
    async def get_candidates(
        self,
        request: Request,
        exam_id: int,
        db: AsyncSession = Depends(get_db),
    ):
        try:
            repo = ExamRepository(db)
            result = await repo.get_candidates(exam_id=exam_id)
            return result
        except HTTPException:
            raise
        except Exception as e:
            self.logger.exception("Failed to fetch candidates", exc_info=e)
            raise HTTPException(
                status_code=500,
                detail=str(e),
            )    
    async def upload_candidates(
        self,
        exam_id: int,
        username: str,
        file: UploadFile = File(...),
        db: AsyncSession = Depends(get_db),
    ):
        contents = await file.read()
        repo = ExamRepository(db)
        return await repo.upload_candidates(
            exam_id=exam_id,
            username=username,
            file_contents=contents,
            filename=file.filename,
        )

    async def serve_exam_file(self, filename: str):
        base_dir = os.path.abspath("uploads/exam_objections")
        full_path = os.path.abspath(os.path.join(base_dir, filename))
        if not full_path.startswith(base_dir):
            raise HTTPException(status_code=403, detail="Access denied")
        if not os.path.exists(full_path):
            raise HTTPException(status_code=404, detail=f"File not found: {filename}")
        return FileResponse(
            path=full_path,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"inline; filename={filename}"  
            }
        )

    async def delete_exam(
        self,
        request: Request,
        exam_id: int,
        db: AsyncSession = Depends(get_db),
    ):
        try:
            username = ( request.headers.get("username") or "SYSTEM")
            repo = ExamRepository(db)
            result = await repo.delete_exam(
                exam_id=exam_id,
                username=username
            )
            return result
        except HTTPException:
            raise
        except Exception as e:
            self.logger.exception( "Failed to delete exam",exc_info=e)
            raise HTTPException(
                status_code=500,
                detail=str(e)
            )

    async def save_exam(
        self,
        request: Request,
        exam_id: int | None = Form(None),
        exam_title: str = Form(...),
        exam_date: str = Form(...),
        no_of_questions: int = Form(...),
        total_answer_options: int = Form(...),
        objection_raise_start_time: str | None = Form(None),
        objection_raise_end_time: str | None = Form(None),
        xobjection_start_time: str | None = Form(None),
        xobjection_end_time: str | None = Form(None),
        active: str = Form(...),
        quetion_booklet_file:  UploadFile | None = File(None),
        answer_booklet_file:  UploadFile | None = File(None),
        db: AsyncSession = Depends(get_db),
    ):
        try:
            payload = SaveExamRequest(
                exam_id=exam_id,
                exam_title=exam_title,
                exam_date=exam_date,
                no_of_questions=no_of_questions,
                total_answer_options= total_answer_options,
                objection_raise_start_time= objection_raise_start_time,
                objection_raise_end_time= objection_raise_end_time,
                xobjection_start_time= xobjection_start_time,
                xobjection_end_time= xobjection_end_time,
                active=active,
            )

            username = (request.headers.get("username") or "SYSTEM")
            repo = ExamRepository(db)
            result = await repo.save_exam(
                payload=payload,
                username=username,
                quetion_booklet_file=
                    quetion_booklet_file,
                answer_booklet_file=
                    answer_booklet_file,
            )
            return result
        except HTTPException:
            raise
        except Exception as e:
            self.logger.exception( "Failed to save exam",exc_info=e)
            raise HTTPException(
                status_code=500,
                detail=str(e)
            )

    async def get_exam_list(
        self,
        request: Request,
        db: AsyncSession = Depends(get_db),
    ):
        try:
            self.logger.info("Fetching Exam List" )
            repo = ExamRepository(db)
            result = await repo.get_all_exams()
            return result
        except HTTPException:
            raise
        except Exception as e:
            self.logger.exception( "Failed to fetch exam list", e)
            raise HTTPException(
                status_code=500,
                detail=str(e)
            )
exam_objection_router = ExamRouter().router