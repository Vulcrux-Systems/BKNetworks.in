from fastapi import APIRouter, Depends,Query

from src.repo.engine import get_db
from src.repo.exam_objections_admin.ExamQuestionRepo import ExamQuestionRepo
from src.services.exam_objections_admin.exam_objections_service import ExamObjectionsService

from src.request.exam_objections_admin.Examquestions_request import (
    UpdateQuestionRequest,
    ObjectionsReportRequest
)

router = APIRouter(prefix="/exams-question", tags=["Exam Questions"])


@router.get("/get-exam")
async def get_exams(db=Depends(get_db)):
    """
    PHP: dropdown from M_PHHC_EXAM where active='Y'
    """
    repo = ExamQuestionRepo(db)
    return await repo.get_exams()


@router.get("/questions-list")
async def get_questions_list(exam_id: int, db=Depends(get_db)):
    """
    PHP: get_examination_questions_list.php
    Returns question_no + question_statement for dropdown
    """
    repo = ExamQuestionRepo(db)
    return await repo.get_questions_list(exam_id)


@router.get("/question-detail")
async def get_question_detail(exam_id: int, question_id: int, db=Depends(get_db)):
    """
    PHP: get_examination_questions.php
    Returns full question detail for edit modal
    """
    repo = ExamQuestionRepo(db)
    return await repo.get_question_detail(exam_id, question_id)


@router.post("/update-question")
async def update_question(payload: UpdateQuestionRequest, db=Depends(get_db)):
    """
    PHP: proc_phhc_exam_questions (Oracle procedure → plain UPDATE in Postgres)
    """
    repo = ExamQuestionRepo(db)
    return await repo.update_question(
        exam_id=payload.exam_id,
        question_id=payload.question_id,
        question=payload.question,
        option1=payload.option1,
        option2=payload.option2,
        option3=payload.option3,
        option4=payload.option4,
        correct=payload.correct,
        xobj_allowed=payload.xobj_allowed,
        xobj_answer=payload.xobj_answer or "",
        username=payload.username,
    )
    
@router.post("/objections-report")
async def get_objections_report(
    payload: ObjectionsReportRequest,
    db=Depends(get_db),
):
    repo    = ExamQuestionRepo(db)
    service = ExamObjectionsService(repo)
    return await service.get_objections_report(
        exam_id  = payload.exam_id,
        order_by = payload.order_by or "Q",
        obj_type = payload.obj_type or "O",
    )

@router.get("/chart-data")
async def get_chart_data(
    exam_id:  int = Query(...),
    obj_type: str = Query("O"),   
    db=Depends(get_db),
):
    repo    = ExamQuestionRepo(db)
    service = ExamObjectionsService(repo)
    return await service.get_chart_data(exam_id=exam_id, obj_type=obj_type)
 