"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import Swal from "sweetalert2";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_BACKEND_CIS_API_URL ||
  process.env.NEXT_PUBLIC_BACKEND_MASTERS_API_URL ||
  "";

interface ExamRecord {
  exam_id: number;
  exam_title: string;
  exam_date: string;                        
  no_of_questions: number;
  total_answer_options: number;
  objection_raise_start_time: string | null; 
  objection_raise_end_time: string | null;
  xobjection_start_time: string | null;
  xobjection_end_time: string | null;
  question_booklet_url: string | null;
  answer_booklet_url: string | null;
  active: string;      
  active_value: string; 
}

interface FormState {
  exam_id: number | null;
  exam_title: string;
  exam_date: string;
  no_of_questions: string;
  total_answer_options: string;
  objection_raise_start_time: string;
  objection_raise_end_time: string;
  xobjection_start_time: string;
  xobjection_end_time: string;
  active: string;
}

interface FormErrors {
  exam_title?: string;
  exam_date?: string;
  no_of_questions?: string;
  total_answer_options?: string;
  objection_raise_start_time?: string;
  objection_raise_end_time?: string;
  xobjection_start_time?: string;
  xobjection_end_time?: string;
  active?: string;
  quetion_booklet_file?: string;
  answer_booklet_file?: string;
}

const EMPTY_FORM: FormState = {
  exam_id: null,
  exam_title: "",
  exam_date: "",
  no_of_questions: "",
  total_answer_options: "",
  objection_raise_start_time: "",
  objection_raise_end_time: "",
  xobjection_start_time: "",
  xobjection_end_time: "",
  active: "",
};

function fmtDate(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return isNaN(d.getTime())
    ? iso
    : d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

function fmtDateTime(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return isNaN(d.getTime())
    ? iso
    : d.toLocaleString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      });
}

function validatePdfFile(file: File): string | null {
  if (file.type !== "application/pdf") return "File Type is not valid";
  const name = file.name;
  const dotIdx = name.lastIndexOf(".");
  if (name.substring(0, dotIdx).length === 0) return "File without name is not allowed";
  if ((name.match(/\./g) ?? []).length > 1) return "Double extension file upload is not allowed";
  if (name.length > 50) return "File name must be less than 50 characters";
  if (file.size / 1024 / 1024 > 1) return "Max File size: 1 MB allowed";
  if (name.substring(dotIdx + 1).toLowerCase() !== "pdf") return "pdf file only";
  return null;
}

export default function AddExamPage() {
  const router = useRouter();
  const [username, setUsername] = useState<string>("SYSTEM");
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [exams, setExams] = useState<ExamRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const qFileRef = useRef<HTMLInputElement>(null);
  const aFileRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const fetchAuthStatus = async () => {
      try {
        const res = await fetch("/api/auth/status");
        if (!res.ok) { router.replace("/logout"); return; }
        const data = await res.json();
        if (!data?.user?.username) { router.replace("/logout"); return; }
        setUsername(data.user.username);
      } catch {
        router.replace("/logout");
      }
    };
    fetchAuthStatus();
  }, [router]);

  const loadExams = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/exam_objection/exams/`, {
        headers: { username },
      });
      if (!res.ok) throw new Error("Failed to fetch exams");
      const data: ExamRecord[] = await res.json();
      setExams(data);
    } catch {
      setExams([]);
    } finally {
      setLoading(false);
    }
  }, [username]);

  useEffect(() => { loadExams(); }, [loadExams]);
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const onlyNumbers = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key.length === 1 && !/[0-9]/.test(e.key)) e.preventDefault();
  };

  const handleFileChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    field: "quetion_booklet_file" | "answer_booklet_file"
  ) => {
    setErrors((prev) => ({ ...prev, [field]: undefined }));
    const file = e.target.files?.[0];
    if (!file) return;
    const err = validatePdfFile(file);
    if (err) {
      setErrors((prev) => ({ ...prev, [field]: err }));
      e.target.value = "";
    }
  };

  const validate = (): boolean => {
    const e: FormErrors = {};
    const numPat = /^[0-9]+$/;
    if (!form.exam_title.trim()) e.exam_title = "Required";
    if (!form.exam_date) e.exam_date = "Required";
    if (!form.no_of_questions) e.no_of_questions = "Required";
    else if (!numPat.test(form.no_of_questions)) e.no_of_questions = "Numeric only";
    if (!form.total_answer_options) e.total_answer_options = "Required";
    else if (!numPat.test(form.total_answer_options)) e.total_answer_options = "Numeric only";
    const os = form.objection_raise_start_time;
    const oe = form.objection_raise_end_time;
    if (os && !oe) e.objection_raise_end_time = "End time required when start is set";
    if (!os && oe) e.objection_raise_start_time = "Start time required when end is set";
    if (os && oe && new Date(oe) <= new Date(os))
      e.objection_raise_end_time = "End time must be after start time";
    const xs = form.xobjection_start_time;
    const xe = form.xobjection_end_time;
    if (xs && !xe) e.xobjection_end_time = "End time required when start is set";
    if (!xs && xe) e.xobjection_start_time = "Start time required when end is set";
    if (xs && xe && new Date(xe) <= new Date(xs))
      e.xobjection_end_time = "End time must be after start time";
    if (!form.active) e.active = "Required";
    const qf = qFileRef.current?.files?.[0];
    if (qf) { const err = validatePdfFile(qf); if (err) e.quetion_booklet_file = err; }
    const af = aFileRef.current?.files?.[0];
    if (af) { const err = validatePdfFile(af); if (err) e.answer_booklet_file = err; }
    setErrors(e);
    return Object.keys(e).length === 0;
  };
  
  const handleSubmit = async () => {
    if (!validate()) return;
    try {
      setSubmitting(true);
      const fd = new FormData();
      if (form.exam_id) fd.append("exam_id", String(form.exam_id));
      fd.append("exam_title", form.exam_title);
      fd.append("exam_date", form.exam_date);
      fd.append("no_of_questions", form.no_of_questions);
      fd.append("total_answer_options", form.total_answer_options);
      fd.append("active", form.active);
      fd.append("objection_raise_start_time", form.objection_raise_start_time || "");
      fd.append("objection_raise_end_time", form.objection_raise_end_time || "");
      fd.append("xobjection_start_time", form.xobjection_start_time || "");
      fd.append("xobjection_end_time", form.xobjection_end_time || "");
      if (qFileRef.current?.files?.[0]) fd.append("quetion_booklet_file", qFileRef.current.files[0]);
      if (aFileRef.current?.files?.[0]) fd.append("answer_booklet_file", aFileRef.current.files[0]);

      const res = await fetch(`${API_BASE_URL}/exam_objection/save-exam`, {
        method: "POST",
        headers: { username },
        body: fd,
      });
      const result = await res.json();
      if (res.ok) {
        Swal.fire("Success", result.message, "success");
        handleClear();
        await loadExams();
      } else {
        Swal.fire("Error", result.detail || "Failed", "error");
      }
    } catch (error) {
      console.error(error);
      Swal.fire("Error", "Something went wrong", "error");
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = (examId: number) => {
    const ex = exams.find((e) => e.exam_id === examId);
    if (!ex) {
      Swal.fire("Error", "Exam record not found.", "error");
      return;
    }
    setForm({
      exam_id: ex.exam_id,
      exam_title: ex.exam_title ?? "",
      exam_date: ex.exam_date ?? "",                                          
      no_of_questions: String(ex.no_of_questions ?? ""),
      total_answer_options: String(ex.total_answer_options ?? ""),
      objection_raise_start_time: ex.objection_raise_start_time ?? "",       
      objection_raise_end_time: ex.objection_raise_end_time ?? "",
      xobjection_start_time: ex.xobjection_start_time ?? "",
      xobjection_end_time: ex.xobjection_end_time ?? "",
      active: ex.active_value ?? "",                                          
    });

    setErrors({});
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDelete = async (examId: number) => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "This exam record will be permanently deleted.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#6c757d",
      confirmButtonText: "Yes, delete it!",
    });
    if (!result.isConfirmed) return;
    try {
      const res = await fetch(`${API_BASE_URL}/exam_objection/delete_exam/${examId}`, {
        method: "DELETE",
        headers: { username },
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Delete failed");
      }
      Swal.fire("Deleted!", "Exam has been deleted.", "success");
      await loadExams();
    } catch (err: unknown) {
      Swal.fire(
        "Error",
        err instanceof Error ? err.message : "Delete failed.",
        "error"
      );
    }
  };
  const handleClear = () => {
    setForm(EMPTY_FORM);
    setErrors({});
    if (qFileRef.current) qFileRef.current.value = "";
    if (aFileRef.current) aFileRef.current.value = "";
  };
  const isEditing = form.exam_id !== null;

  return (
    <div className="container py-4">
      <div className="card shadow-sm border-0 mb-4">
        <div className="card-header bg-dark text-white">
          <h5 className="mb-0">
            {isEditing ? "Edit Exam Details" : "Add Exam Details"}
          </h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-6 mb-3">
              <label><span className="text-danger">*</span> Exam Title</label>
              <input
                type="text"
                name="exam_title"
                value={form.exam_title}
                onChange={handleChange}
                className="form-control"
                maxLength={200}
              />
              <div className="text-danger">{errors.exam_title}</div>
            </div>
            <div className="col-md-3 mb-3">
              <label><span className="text-danger">*</span> Exam Date</label>
              <input
                type="date"
                name="exam_date"
                value={form.exam_date}
                onChange={handleChange}
                onKeyDown={(e) => e.preventDefault()}
                className="form-control"
              />
              <div className="text-danger">{errors.exam_date}</div>
            </div>
            <div className="col-md-3 mb-3">
              <label><span className="text-danger">*</span> Display</label>
              <select
                name="active"
                value={form.active}
                onChange={handleChange}
                className="form-control"
              >
                <option value="">-- Select Display --</option>
                <option value="Y">Yes</option>
                <option value="N">No</option>
              </select>
              <div className="text-danger">{errors.active}</div>
            </div>
            <div className="col-md-3 mb-3">
              <label><span className="text-danger">*</span> No. of Questions</label>
              <input
                type="text"
                name="no_of_questions"
                value={form.no_of_questions}
                onChange={handleChange}
                onKeyPress={onlyNumbers}
                className="form-control"
                maxLength={3}
              />
              <div className="text-danger">{errors.no_of_questions}</div>
            </div>
            <div className="col-md-3 mb-3">
              <label><span className="text-danger">*</span> Total Answer Options</label>
              <input
                type="text"
                name="total_answer_options"
                value={form.total_answer_options}
                onChange={handleChange}
                onKeyPress={onlyNumbers}
                className="form-control"
                maxLength={1}
              />
              <div className="text-danger">{errors.total_answer_options}</div>
            </div>
            <div className="col-md-3 mb-3">
              <label>Objection Raise Start Time</label>
              <input
                type="datetime-local"
                name="objection_raise_start_time"
                value={form.objection_raise_start_time}
                onChange={handleChange}
                onKeyDown={(e) => e.preventDefault()}
                className="form-control"
              />
              <div className="text-danger">{errors.objection_raise_start_time}</div>
            </div>
            <div className="col-md-3 mb-3">
              <label>Objection Raise End Time</label>
              <input
                type="datetime-local"
                name="objection_raise_end_time"
                value={form.objection_raise_end_time}
                onChange={handleChange}
                onKeyDown={(e) => e.preventDefault()}
                className="form-control"
              />
              <div className="text-danger">{errors.objection_raise_end_time}</div>
            </div>
            <div className="col-md-3 mb-3">
              <label>XObjection Raise Start Time</label>
              <input
                type="datetime-local"
                name="xobjection_start_time"
                value={form.xobjection_start_time}
                onChange={handleChange}
                onKeyDown={(e) => e.preventDefault()}
                className="form-control"
              />
              <div className="text-danger">{errors.xobjection_start_time}</div>
            </div>
            <div className="col-md-3 mb-3">
              <label>XObjection Raise End Time</label>
              <input
                type="datetime-local"
                name="xobjection_end_time"
                value={form.xobjection_end_time}
                onChange={handleChange}
                onKeyDown={(e) => e.preventDefault()}
                className="form-control"
              />
              <div className="text-danger">{errors.xobjection_end_time}</div>
            </div>
            <div className="col-md-6 mb-3">
              <label>
                Upload Question Booklet{" "}
                <small className="text-muted">(PDF, max 1 MB)</small>
              </label>
              <input
                type="file"
                ref={qFileRef}
                accept=".pdf,application/pdf"
                onChange={(e) => handleFileChange(e, "quetion_booklet_file")}
                className="form-control"
              />
              <div className="text-danger">{errors.quetion_booklet_file}</div>
            </div>
            <div className="col-md-6 mb-3">
              <label>
                Upload Answer Booklet{" "}
                <small className="text-muted">(PDF, max 1 MB)</small>
              </label>
              <input
                type="file"
                ref={aFileRef}
                accept=".pdf,application/pdf"
                onChange={(e) => handleFileChange(e, "answer_booklet_file")}
                className="form-control"
              />
              <div className="text-danger">{errors.answer_booklet_file}</div>
            </div>
            <div className="col-md-12 mt-2">
              <button
                className="btn btn-success me-2"
                onClick={handleSubmit}
                disabled={submitting}
              >
                {submitting ? "Saving..." : isEditing ? "Update" : "Save"}
              </button>
              <button
                className="btn btn-danger"
                onClick={handleClear}
                disabled={submitting}
              >
                Cancel
              </button>
            </div>

          </div>
        </div>
      </div>

      {loading && (
        <div className="text-center mb-3">
          <strong>Loading...</strong>
        </div>
      )}

      {!loading && (
        <div className="card shadow-sm border-0">
          <div className="card-header bg-dark text-white">
            <h6 className="mb-0">Exam Records List</h6>
          </div>
          <div className="card-body table-responsive">
            <table className="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>EXAM TITLE</th>
                  <th>DATE</th>
                  <th>QUESTIONS</th>
                  <th>OPTIONS</th>
                  <th>OBJ. START</th>
                  <th>OBJ. END</th>
                  <th>XOBJ. START</th>
                  <th>XOBJ. END</th>
                  <th>DISPLAY</th>
                  <th>QUES. PDF</th>
                  <th>ANS. PDF</th>
                  <th>ACTION</th>
                </tr>
              </thead>
              <tbody>
                {exams.length === 0 ? (
                  <tr>
                    <td colSpan={13} className="text-center text-danger">
                      No Record Found
                    </td>
                  </tr>
                ) : (
                  exams.map((ex, i) => (
                    <tr key={ex.exam_id}>
                      <td>{i + 1}</td>
                      <td>{ex.exam_title}</td>
                      <td>{fmtDate(ex.exam_date)}</td>
                      <td className="text-center">{ex.no_of_questions}</td>
                      <td className="text-center">{ex.total_answer_options}</td>
                      <td>{fmtDateTime(ex.objection_raise_start_time)}</td>
                      <td>{fmtDateTime(ex.objection_raise_end_time)}</td>
                      <td>{fmtDateTime(ex.xobjection_start_time)}</td>
                      <td>{fmtDateTime(ex.xobjection_end_time)}</td>
                      <td className="text-center">
                        {ex.active_value === "Y" ? (
                          <span className="badge bg-success">Yes</span>
                        ) : (
                          <span className="badge bg-secondary">No</span>
                        )}
                      </td>
                      <td className="text-center">
                        {ex.question_booklet_url ? (
                          <a
                            
                            href={`/api/exam_objections_admin?filename=${ex.question_booklet_url}`}
                            target="_blank"
                            rel="noreferrer"
                            className="btn btn-sm btn-outline-primary"
                          >
                            View
                          </a>
                        ) : "—"}
                      </td>
                      <td className="text-center">
                        {ex.answer_booklet_url ? (
                          <a
                            href={`/api/exam_objections_admin?filename=${ex.answer_booklet_url}`}
                            target="_blank"
                            rel="noreferrer"
                            className="btn btn-sm btn-outline-primary"
                          >
                            View
                          </a>
                        ) : "—"}
                      </td>
                      <td>
                        <div className="d-flex align-items-center gap-1">
                            <button
                            className="btn btn-sm btn-primary"
                            onClick={() => handleEdit(ex.exam_id)}
                            >
                            Edit
                            </button>
                            <button
                            className="btn btn-sm btn-danger"
                            onClick={() => handleDelete(ex.exam_id)}
                            >
                            X
                            </button>
                        </div>
                        </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
}