"use client";

import { useEffect, useState } from "react";
import Swal from "sweetalert2";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_BACKEND_CIS_API_URL ||
  process.env.NEXT_PUBLIC_BACKEND_MASTERS_API_URL ||
  "";

interface Exam {
  exam_id: number;
  exam_title: string;
}

interface QuestionItem {
  question_no: number;
  question_statement: string;
}

interface QuestionDetail {
  QUESTION_NO: number;
  EXAM_ID: number;
  QUESTION_STATEMENT: string;
  OPTION_1: string;
  OPTION_2: string;
  OPTION_3: string;
  OPTION_4: string;
  CORRECT_OPTION: string;
  XOBJ_ALLOWED: string;
  XOBJ_ANSWER_OPTION: string;
}


const OPTION_LABELS: Record<string, string> = {
  "1": "a", "2": "b", "3": "c", "4": "d", "9": "x"
};

function getXobjOptions(correctOption: string): { label: string; value: string }[] {
  const all = [
    { value: "1", label: "a" },
    { value: "2", label: "b" },
    { value: "3", label: "c" },
    { value: "4", label: "d" },
    { value: "9", label: "x" },
  ];
  
  return all.filter(o => o.value !== correctOption);
}


export default function ExamQuestionPage() {

  const [exams,          setExams]          = useState<Exam[]>([]);
  const [questions,      setQuestions]      = useState<QuestionItem[]>([]);
  const [selectedExam,   setSelectedExam]   = useState<string>("");
  const [selectedQn,     setSelectedQn]     = useState<string>("");
  const [detail,         setDetail]         = useState<QuestionDetail | null>(null);
  const [modalOpen,      setModalOpen]      = useState(false);
  const [saving,         setSaving]         = useState(false);


  const [question,     setQuestion]     = useState("");
  const [option1,      setOption1]      = useState("");
  const [option2,      setOption2]      = useState("");
  const [option3,      setOption3]      = useState("");
  const [option4,      setOption4]      = useState("");
  const [correct,      setCorrect]      = useState("1");
  const [xobjAllowed,  setXobjAllowed]  = useState("N");
  const [xobjAnswer,   setXobjAnswer]   = useState("");

  useEffect(() => {
    fetchExams();
  }, []);

  const fetchExams = async () => {
    try {
      const res  = await fetch(`${API_BASE_URL}/exams-question/get-exam`);
      const data = await res.json();
      setExams(data || []);
      if (data?.length > 0) {
        const defaultId = String(data[0].exam_id);
        setSelectedExam(defaultId);
        await fetchQuestions(defaultId);
      }
    } catch { console.error("Failed to load exams"); }
  };

  const fetchQuestions = async (examId: string) => {
    if (!examId) return;
    try {
      const res  = await fetch(`${API_BASE_URL}/exams-question/questions-list?exam_id=${examId}`);
      const data = await res.json();
      setQuestions(data || []);
      setSelectedQn("");
      setDetail(null);
      setModalOpen(false);
    } catch { console.error("Failed to load questions"); }
  };

  const fetchQuestionDetail = async (questionId: string) => {
    if (!questionId || !selectedExam) return;
    try {
      const res  = await fetch(
        `${API_BASE_URL}/exams-question/question-detail?exam_id=${selectedExam}&question_id=${questionId}`
      );
      const data = await res.json();

      if (data.status === "True" && data.data) {
        const d: QuestionDetail = data.data;
        setDetail(d);

        setQuestion(d.QUESTION_STATEMENT || "");
        setOption1(d.OPTION_1 || "");
        setOption2(d.OPTION_2 || "");
        setOption3(d.OPTION_3 || "");
        setOption4(d.OPTION_4 || "");
        setCorrect(String(d.CORRECT_OPTION || "1"));
        setXobjAllowed(d.XOBJ_ALLOWED || "N");
        setXobjAnswer(String(d.XOBJ_ANSWER_OPTION || ""));

        setModalOpen(true);
      }
    } catch { console.error("Failed to load question detail"); }
  };

  const handleXobjAllowedChange = (val: string) => {
    setXobjAllowed(val);
    if (val === "N") {
      setXobjAnswer("");
    }
  };

  const handleSubmit = async () => {
    if (!question || !option1 || !option2 || !option3 || !option4 || !correct || !selectedExam) {
      Swal.fire("Validation", "All fields are mandatory", "warning");
      return;
    }

    setSaving(true);
    try {
		const authRes  = await fetch('/api/auth/status');
      const authData = await authRes.json();
      const userid   = authData?.user?.username || null;
      const res  = await fetch(`${API_BASE_URL}/exams-question/update-question`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          exam_id:      parseInt(selectedExam),
          question_id:  detail?.QUESTION_NO,
          question,
          option1, option2, option3, option4,
          correct,
          xobj_allowed: xobjAllowed,
          xobj_answer:  xobjAnswer,
          username:     userid, 
        }),
      });
      const data = await res.json();

      if (data.status === "SUCCESS") {
        Swal.fire("Success", "Question Updated Successfully", "success");
        closeModal();
		fetchQuestions(parseInt(selectedExam));
      } else {
        Swal.fire("Error", data.message || "Error updating question", "error");
      }
    } catch {
      Swal.fire("Error", "Server error", "error");
    } finally {
      setSaving(false);
    }
  };

  const closeModal = () => {
    setModalOpen(false);
    setDetail(null);
    setQuestion(""); setOption1(""); setOption2("");
    setOption3(""); setOption4(""); setCorrect("1");
    setXobjAllowed("N"); setXobjAnswer("");
  };

  const xobjOptions = getXobjOptions(correct);

  return (
    <>
      <style jsx global>{`
        .modal-backdrop-custom {
          position: fixed; inset: 0;
          background: rgba(0,0,0,0.6);
          z-index: 1000;
          display: flex; align-items: center; justify-content: center;
        }
        .modal-box {
          background: #fff;
          border: 4px solid orange;
          border-radius: 6px;
          padding: 24px;
          width: 560px;
          max-height: 85vh;
          overflow-y: auto;
          position: relative;
          z-index: 1001;
        }
        .modal-close {
          position: absolute; top: 10px; right: 14px;
          font-size: 18px; cursor: pointer; font-weight: bold;
          background: none; border: none; color: #333;
        }
        .form-row { margin-bottom: 14px; }
        .form-row label { font-weight: 600; display: block; margin-bottom: 4px; }
        .form-row input, .form-row select, .form-row textarea {
          width: 100%; padding: 6px 10px;
          border: 1px solid #ccc; border-radius: 4px;
          font-size: 13px;
        }
        .form-row textarea { resize: vertical; min-height: 60px; }
      `}</style>

      <div className="container-fluid py-3">

        
        <div className="card">
          <div className="card-header bg-dark text-white">
            <strong>Add / Edit Question Answer</strong>
          </div>

          <div className="card-body">
            <div className="row g-3">

             
              <div className="col-md-5">
                <label className="form-label fw-semibold">Select Examination</label>
                <select
                  className="form-select form-select-sm"
                  value={selectedExam}
                  onChange={(e) => {
                    setSelectedExam(e.target.value);
                    fetchQuestions(e.target.value);
                  }}
                >
                  <option value="">-- Select --</option>
                  {exams.map((ex) => (
                    <option key={ex.exam_id} value={String(ex.exam_id)}>
                      {ex.exam_title}
                    </option>
                  ))}
                </select>
              </div>

            
              <div className="col-md-7">
                <label className="form-label fw-semibold">Select Question</label>
                <select
                  className="form-select form-select-sm"
                  value={selectedQn}
                  onChange={(e) => {
                    setSelectedQn(e.target.value);
                    fetchQuestionDetail(e.target.value);
                  }}
                >
                  <option value="">- Select -</option>
                  {questions.map((q) => (
                    <option key={q.question_no} value={String(q.question_no)}>
                      {q.question_no}: {q.question_statement}
                    </option>
                  ))}
                </select>
              </div>

            </div>
          </div>
        </div>

        
        {questions.length > 0 && (
          <div className="mt-3 card">
            <div className="card-header bg-secondary text-white">
              Questions List
            </div>
            <div className="card-body p-0">
              <table className="table table-striped table-bordered table-sm mb-0">
                <thead className="table-dark">
                  <tr>
                    <th style={{ width: 60 }}>#</th>
                    <th>Question</th>
                    <th style={{ width: 80 }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {questions.map((q) => (
                    <tr key={q.question_no}>
                      <td>{q.question_no}</td>
                      <td>{q.question_statement}</td>
                      <td>
                        <button
                          className="btn btn-warning btn-sm"
                          onClick={() => {
                            setSelectedQn(String(q.question_no));
                            fetchQuestionDetail(String(q.question_no));
                          }}
                        >
                          Edit
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

     
      {modalOpen && (
        <div className="modal-backdrop-custom" onClick={closeModal}>
          <div className="modal-box" onClick={(e) => e.stopPropagation()}>

            <button className="modal-close" onClick={closeModal}>X</button>
            <h6 className="mb-3 fw-bold border-bottom pb-2">Edit Question</h6>

            
            <div className="form-row">
              <label>Question :-</label>
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                required
              />
            </div>

           
            {[
              { label: "Option a :-", val: option1, set: setOption1 },
              { label: "Option b :-", val: option2, set: setOption2 },
              { label: "Option c :-", val: option3, set: setOption3 },
              { label: "Option d :-", val: option4, set: setOption4 },
            ].map(({ label, val, set }, i) => (
              <div className="form-row" key={i}>
                <label>{label}</label>
                <input
                  type="text"
                  value={val}
                  onChange={(e) => set(e.target.value)}
                  required
                />
              </div>
            ))}

           
            <div className="form-row">
              <label>Correct :-</label>
              <select
                value={correct}
                onChange={(e) => {
                  setCorrect(e.target.value);
                  setXobjAnswer(""); 
                }}
              >
                <option value="1">a</option>
                <option value="2">b</option>
                <option value="3">c</option>
                <option value="4">d</option>
                <option value="9">x</option>
              </select>
            </div>

            
            <div className="form-row">
              <label>Cross Objection Allowed :-</label>
              <select
                value={xobjAllowed}
                onChange={(e) => handleXobjAllowedChange(e.target.value)}
              >
                <option value="Y">YES</option>
                <option value="N">NO</option>
              </select>
            </div>

           
            <div className="form-row">
              <label>Cross Objection Answer :-</label>
              <select
                value={xobjAnswer}
                onChange={(e) => setXobjAnswer(e.target.value)}
                disabled={xobjAllowed === "N"}
              >
                {xobjAllowed === "N" ? (
                  <option value="">No objection allowed</option>
                ) : (
                  <>
                    <option value="">-- Select --</option>
                    {xobjOptions.map((o) => (
                      <option key={o.value} value={o.value}>{o.label}</option>
                    ))}
                  </>
                )}
              </select>
            </div>

            
            <div className="text-center mt-3">
              <button
                className="btn btn-success px-4"
                onClick={handleSubmit}
                disabled={saving}
              >
                {saving
                  ? <><span className="spinner-border spinner-border-sm me-1" />Saving...</>
                  : "Submit"}
              </button>
              <button
                className="btn btn-secondary ms-2 px-4"
                onClick={closeModal}
              >
                Cancel
              </button>
            </div>

          </div>
        </div>
      )}
    </>
  );
}
