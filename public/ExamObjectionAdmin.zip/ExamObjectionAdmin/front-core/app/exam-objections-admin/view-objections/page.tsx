"use client";

import { useEffect, useRef, useState } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";
import Swal from "sweetalert2";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const API_BASE_URL =
  process.env.NEXT_PUBLIC_BACKEND_CIS_API_URL ||
  process.env.NEXT_PUBLIC_BACKEND_MASTERS_API_URL ||
  "";


interface Exam {
  exam_id: number;
  exam_title: string;
}

interface ChartItem {
  language: string;
  total: number;
  color: string;
}

interface QuestionRow {
  exam_id:            number;
  question_no:        number;
  question_statement: string;
  option_1:           string;
  option_2:           string;
  option_3:           string;
  option_4:           string;
  option_e:           string;
  correct_option:     string;
  is_deleted:         boolean;
  obj_cnt_a:          number;
  obj_cnt_b:          number;
  obj_cnt_c:          number;
  obj_cnt_d:          number;
  obj_cnt_e:          number;
  total_obj:          number;
}

interface ReportData {
  success:          boolean;
  exam_id:          number;
  exam_title:       string;
  exam_date:        string;
  rep_type:         string;
  obj_grand_total:  number;
  obj_question_cnt: number;
  questions:        QuestionRow[];
}


export default function ViewObjectionsPage() {

  const [exams,      setExams]      = useState<Exam[]>([]);
  const [examId,     setExamId]     = useState<string>("");
  const [objType,    setObjType]    = useState<string>("O");
  const [orderBy,    setOrderBy]    = useState<string>("Q");
  const [loading,    setLoading]    = useState(false);
  const [hasResult,  setHasResult]  = useState(false);
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [chartItems, setChartItems] = useState<ChartItem[]>([]);


  useEffect(() => {
    fetchExams();
  }, []);

  const fetchExams = async () => {
    try {
      const res  = await fetch(`${API_BASE_URL}/exams-question/get-exam`);
      const data = await res.json();
      setExams(data || []);
    } catch {
      console.error("Failed to load exams");
    }
  };

  const fetchChartData = async (eid: string, otype: string) => {
    if (!eid) return;
    try {
      const res  = await fetch(
        `${API_BASE_URL}/exams-question/chart-data?exam_id=${eid}&obj_type=${otype}`
      );
      const data = await res.json();
      setChartItems(data || []);
    } catch {
      console.error("Chart data fetch failed");
    }
  };

  const handleSubmit = async () => {
    if (!examId) {
      Swal.fire("Validation", "Please select an examination", "warning");
      return;
    }

    setLoading(true);
    setHasResult(false);
    setReportData(null);
    setChartItems([]);

    try {
      // Fetch chart + report in parallel
      const [chartRes, reportRes] = await Promise.all([
        fetch(
          `${API_BASE_URL}/exams-question/chart-data?exam_id=${examId}&obj_type=${objType}`
        ),
        fetch(`${API_BASE_URL}/exams-question/objections-report`, {
          method:  "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            exam_id:  parseInt(examId),
            order_by: orderBy,
            obj_type: objType,
          }),
        }),
      ]);

      const chartData  = await chartRes.json();
      const reportJson = await reportRes.json();

      if (reportJson.success) {
        setChartItems(chartData || []);
        setReportData(reportJson);
        setHasResult(true);
      } else {
        Swal.fire("Error", reportJson.message || "No data found", "error");
      }
    } catch {
      Swal.fire("Error", "Server error", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setExamId("");
    setObjType("O");
    setOrderBy("Q");
    setHasResult(false);
    setReportData(null);
    setChartItems([]);
  };


  const barChartData = {
    labels:   chartItems.filter(c => c.language).map(c => c.language),
    datasets: [
      {
        label:           "Objections",
        backgroundColor: chartItems.filter(c => c.language).map(c => c.color),
        data:            chartItems.filter(c => c.language).map(c => c.total),
      },
    ],
  };

  const barChartOptions = {
    responsive: true,
    plugins: {
      legend: { position: "top" as const },
      title:  { display: false },
    },
    scales: {
      y: { beginAtZero: true },
    },
  };


  const getCellStyle = (optionNum: string, correctOption: string): React.CSSProperties =>
    optionNum === correctOption ? { backgroundColor: "#90EE90" } : {};

  const detailLink = (examId: number, type: string, qno: number, objType: string) =>
    `/phhc/view-objection-detail?exam_id=${examId}&type=${type}&ques_no=${qno}&obj_type=${objType}`;


  return (
    <>
      <style jsx global>{`
        .obj-table { width: 80%; border-collapse: collapse; font-size: 14px; margin: 0 auto; }
        .obj-table th, .obj-table td {
          border: 1px solid #999; padding: 6px 8px; vertical-align: top;
        }
        .obj-table tr:nth-child(even) { background: #E8E8E8; }
        .obj-table tr:nth-child(odd)  { background: #DFEFFF; }
        .obj-table thead th           { background: #d0d0d0 !important; text-align: center; }
        .obj-link { font-size: 12px; color: #0d6efd; text-decoration: underline; cursor: pointer; }
        .deleted-q { color: red; text-decoration: line-through; }
      `}</style>

      <div className="container-fluid py-3">


        <div className="card">
          <div className="card-header bg-dark text-white">
            <strong>View Examination Objections / X-Objections</strong>
          </div>
          <div className="card-body">
            <div className="row g-3 align-items-end">

         
              <div className="col-md-4">
                <label className="form-label fw-semibold">
                  <span className="text-danger">* </span>Select Examination
                </label>
                <select
                  className="form-select form-select-sm"
                  value={examId}
                  onChange={(e) => setExamId(e.target.value)}
                >
                  <option value="">-- Select --</option>
                  {exams.map((ex) => (
                    <option key={ex.exam_id} value={String(ex.exam_id)}>
                      {ex.exam_title}
                    </option>
                  ))}
                </select>
              </div>

              
              <div className="col-md-2">
                <label className="form-label fw-semibold">Report Type</label>
                <select
                  className="form-select form-select-sm"
                  value={objType}
                  onChange={(e) => setObjType(e.target.value)}
                >
                  <option value="O">Objections</option>
                  <option value="X">X-Objections</option>
                </select>
              </div>

            
              <div className="col-md-3">
                <label className="form-label fw-semibold">Order By</label>
                <select
                  className="form-select form-select-sm"
                  value={orderBy}
                  onChange={(e) => setOrderBy(e.target.value)}
                >
                  <option value="Q">Question No. Wise</option>
                  <option value="O">Objection Count Wise</option>
                </select>
              </div>

         
              <div className="col-md-3 d-flex gap-2">
                <button
                  className="btn btn-success btn-sm"
                  onClick={handleSubmit}
                  disabled={loading}
                >
                  {loading ? (
                    <><span className="spinner-border spinner-border-sm me-1" />Generating...</>
                  ) : (
                    "View Objections"
                  )}
                </button>
                <button className="btn btn-danger btn-sm" onClick={handleReset}>
                  Cancel
                </button>
              </div>

            </div>
          </div>
        </div>

  
        {hasResult && reportData && (
          <div className="mt-3">

          
            {chartItems.some(c => c.total > 0) && (
              <div className="card mt-3 mb-3">
                <div className="card-header bg-dark text-white">
                  List of Top 30 questions with most no. of {reportData.rep_type}
                </div>
                <div className="card-body">
                  <Bar data={barChartData} options={barChartOptions} />
                </div>
              </div>
            )}

         
            <div className="mt-3" style={{ overflowX: "auto" }}>
              <table className="obj-table">
                <thead>
                  <tr>
                    <th colSpan={7}>
                      Summary of {reportData.rep_type} Raised on{" "}
                      <strong>{reportData.exam_title}</strong> Conducted by High Court of
                      Punjab and Haryana conducted on {reportData.exam_date}
                    </th>
                  </tr>
                  <tr>
                    <th>Question Sr. No.</th>
                    <th>Question Statement</th>
                    <th>Option A</th>
                    <th>Option B</th>
                    <th>Option C</th>
                    <th>Option D</th>
                    <th>Option E</th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.questions.map((q) => (
                    <tr key={q.question_no}>

                      
                      <td className="text-center"><strong>{q.question_no}</strong></td>

                     
                      <td>
                        {q.is_deleted ? (
                          <span className="deleted-q">{q.question_statement}</span>
                        ) : (
                          q.question_statement
                        )}
                        <br />
                        <a
                          className="obj-link"
                          href={detailLink(q.exam_id, "ALL", q.question_no, objType)}
                          target="_blank"
                          rel="noreferrer"
                        >
                          Total Objection Count: {q.total_obj}
                        </a>
                      </td>

                    
                      <td style={getCellStyle("1", q.correct_option)}>
                        {q.option_1}
                        <br />
                        <a
                          className="obj-link"
                          href={detailLink(q.exam_id, "A", q.question_no, objType)}
                          target="_blank"
                          rel="noreferrer"
                        >
                          Proposed By: {q.obj_cnt_a}
                        </a>
                      </td>

                     
                      <td style={getCellStyle("2", q.correct_option)}>
                        {q.option_2}
                        <br />
                        <a
                          className="obj-link"
                          href={detailLink(q.exam_id, "B", q.question_no, objType)}
                          target="_blank"
                          rel="noreferrer"
                        >
                          Proposed By: {q.obj_cnt_b}
                        </a>
                      </td>

                    
                      <td style={getCellStyle("3", q.correct_option)}>
                        {q.option_3}
                        <br />
                        <a
                          className="obj-link"
                          href={detailLink(q.exam_id, "C", q.question_no, objType)}
                          target="_blank"
                          rel="noreferrer"
                        >
                          Proposed By: {q.obj_cnt_c}
                        </a>
                      </td>

                     
                      <td style={getCellStyle("4", q.correct_option)}>
                        {q.option_4}
                        <br />
                        <a
                          className="obj-link"
                          href={detailLink(q.exam_id, "D", q.question_no, objType)}
                          target="_blank"
                          rel="noreferrer"
                        >
                          Proposed By: {q.obj_cnt_d}
                        </a>
                      </td>

                     
                      <td>
                        {q.option_e}
                        <br />
                        <a
                          className="obj-link"
                          href={detailLink(q.exam_id, "E", q.question_no, objType)}
                          target="_blank"
                          rel="noreferrer"
                        >
                          Proposed By: {q.obj_cnt_e}
                        </a>
                      </td>

                    </tr>
                  ))}

                 
                  {reportData.obj_question_cnt > 0 && (
                    <tr>
                      <td colSpan={6} className="text-center">
                        <strong>
                          Total {reportData.obj_grand_total} Objections in{" "}
                          {reportData.obj_question_cnt} Questions
                        </strong>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

          </div>
        )}

      </div>
    </>
  );
}