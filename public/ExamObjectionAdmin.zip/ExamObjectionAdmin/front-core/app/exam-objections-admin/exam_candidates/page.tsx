"use client"
import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
const API_BASE_URL =
  process.env.NEXT_PUBLIC_BACKEND_CIS_API_URL ||
  process.env.NEXT_PUBLIC_BACKEND_MASTERS_API_URL ||
  "";

interface Exam {
  exam_id: number
  exam_title: string
}

interface UploadResult {
  inserted: number
  skipped:  number
  errors:   string[]
}

interface Candidate {
  roll_no: string
  name:    string
  mobile:  string
}

export default function UploadCandidates() {
  const router = useRouter()
  const [username,   setUsername]   = useState<string>("")
  const [exams,      setExams]      = useState<Exam[]>([])
  const [examId,     setExamId]     = useState<string>("")
  const [file,       setFile]       = useState<File | null>(null)
  const [loading,    setLoading]    = useState(false)
  const [fetching,   setFetching]   = useState(true)
  const [result,     setResult]     = useState<UploadResult | null>(null)
  const [error,      setError]      = useState<string | null>(null)
  const [candidates,      setCandidates]      = useState<Candidate[]>([])
  const [loadingCandidates, setLoadingCandidates] = useState(false)
  const [candidatesError,   setCandidatesError]   = useState<string | null>(null)
  const [searchQuery,       setSearchQuery]       = useState<string>("")
  const [currentPage,       setCurrentPage]       = useState<number>(1)
  const [showConfirm,       setShowConfirm]       = useState(false)
  const rowsPerPage = 10

  useEffect(() => {
    const fetchAuthStatus = async () => {
      try {
        const res = await fetch("/api/auth/status")
        if (!res.ok) { router.replace("/logout"); return }
        const data = await res.json()
        if (!data?.user?.username) { router.replace("/logout"); return }
        setUsername(data.user.username)
      } catch {
        router.replace("/logout")
      }
    }
    fetchAuthStatus()
  }, [router])


  const loadExams = useCallback(async () => {
    setFetching(true)
    try {
      const res = await fetch(`${API_BASE_URL}/exam_objection/exams/`, {
        headers: { username },
      })
      if (!res.ok) throw new Error("Failed to fetch exams")
      const data: Exam[] = await res.json()
      setExams(data)
    } catch {
      setExams([])
    } finally {
      setFetching(false)
    }
  }, [username])

  useEffect(() => {
    if (username) loadExams()
  }, [username, loadExams])


  const loadCandidates = useCallback(async (selectedExamId: string) => {
    if (!selectedExamId) {
      setCandidates([])
      return
    }
    setLoadingCandidates(true)
    setCandidatesError(null)
    setCandidates([])
    setSearchQuery("")
    setCurrentPage(1)
    try {
      const res = await fetch(
        `${API_BASE_URL}/exam_objection/candidates?exam_id=${selectedExamId}`,
        { headers: { username } }
      )
      if (!res.ok) throw new Error("Failed to fetch candidates")
      const data: Candidate[] = await res.json()
      setCandidates(data)
    } catch {
      setCandidatesError("Could not load candidates for this exam.")
    } finally {
      setLoadingCandidates(false)
    }
  }, [username])

  const handleExamChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value
    setExamId(val)
    setResult(null)
    setError(null)
    loadCandidates(val)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setResult(null)

    if (!examId) { setError("Please select an exam."); return }
    if (!file)   { setError("Please select an Excel file."); return }
    if (candidates.length > 0) {
      setShowConfirm(true)
    } else {
      doUpload()
    }
  }

  const doUpload = async () => {
    setShowConfirm(false)
    setLoading(true)
    try {
      const formData = new FormData()
      formData.append("exam_id",  examId)
      formData.append("username", username)
      formData.append("file",     file!)
      const res = await fetch("/api/exam_candidates", {
        method: "POST",
        body:   formData,
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error || "Upload failed"); return }
      setResult(data)
      setFile(null)
      const fileInput = document.getElementById("candidateFile") as HTMLInputElement
      if (fileInput) fileInput.value = ""
      loadCandidates(examId)
    } catch {
      setError("Something went wrong. Please try again.")
    } finally {
      setLoading(false)
    }
  }


  const filteredCandidates = candidates.filter((c) => {
    const q = searchQuery.toLowerCase()
    return (
      c.name?.toLowerCase().includes(q) ||
      c.roll_no?.toLowerCase().includes(q) ||
      c.mobile?.toLowerCase().includes(q)
    )
  })
  const totalPages   = Math.ceil(filteredCandidates.length / rowsPerPage)
  const pagedCandidates = filteredCandidates.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  )
  const selectedExamTitle = exams.find(
    (ex) => String(ex.exam_id) === examId
  )?.exam_title

  return (
    <>
      <div className="card mb-4">
        <div className="card-header  bg-dark text-light">
          <h5 className="mb-0">Upload Candidates</h5>
        </div>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">
                Select Exam <span className="text-danger">*</span>
              </label>
              {fetching ? (
                <div className="d-flex align-items-center gap-2 text-muted">
                  <span className="spinner-border spinner-border-sm" />
                  Loading exams...
                </div>
              ) : (
                <select
                  className="form-select"
                  value={examId}
                  onChange={handleExamChange}
                >
                  <option value="">— Select Exam —</option>
                  {exams.map((ex) => (
                    <option key={ex.exam_id} value={ex.exam_id}>
                      {ex.exam_title}
                    </option>
                  ))}
                </select>
              )}
            </div>
            <div className="mb-3">
              <label className="form-label">
                Excel File (.xlsx / .xls) <span className="text-danger">*</span>
              </label>
              <input
                id="candidateFile"
                type="file"
                className="form-control"
                accept=".xlsx,.xls"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
              />
              <div className="form-text">
                Required columns: <strong>ROLL_NO, NAME, MOBILE</strong>
              </div>
            </div>
            {error && (
              <div className="alert alert-danger py-2">
                <i className="ti ti-alert-circle me-1" />
                {error}
              </div>
            )}
            {result && (
              <div className="alert alert-success py-2">
                <strong>{result.inserted}</strong> candidates inserted,{" "}
                <strong>{result.skipped}</strong> skipped.
                {result.errors.length > 0 && (
                  <ul className="mb-0 mt-2 small">
                    {result.errors.map((err, i) => (
                      <li key={i} className="text-danger">{err}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}

            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading || fetching || !username}
            >
              {loading
                ? <><span className="spinner-border spinner-border-sm me-2" />Uploading...</>
                : <><i className="ti ti-upload me-1" />Upload Candidates</>
              }
            </button>

          </form>
        </div>
      </div>
      {examId && (
        <div className="card">
          <div className="card-header d-flex align-items-center justify-content-between flex-wrap gap-2 ">
            <h5 className="mb-0 ">
              List of candidates
              {selectedExamTitle && (
                <span className="text-muted fw-normal fs-6 ms-2  ">
                  — {selectedExamTitle}
                </span>
              )}
              {!loadingCandidates && candidates.length > 0 && (
                <span className="badge bg-primary ms-2 text-light">Total Records found : {candidates.length}</span>
              )}
            </h5>
            {candidates.length > 0 && (
              <div className="input-group" style={{ maxWidth: 280 }}>
               
                <input
                  type="text"
                  className="form-control form-control-sm"
                  placeholder="Search name, roll no, mobile…"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value)
                    setCurrentPage(1)
                  }}
                />
              </div>
            )}
          </div>

          <div className="card-body p-0">
            {loadingCandidates && (
              <div className="d-flex align-items-center justify-content-center gap-2 py-5 text-muted">
                <span className="spinner-border spinner-border-sm" />
                Loading candidates…
              </div>
            )}
            {!loadingCandidates && candidatesError && (
              <div className="alert alert-warning m-3">
                <i className="ti ti-alert-triangle me-1" />
                {candidatesError}
              </div>
            )}
            {!loadingCandidates && !candidatesError && candidates.length === 0 && (
              <div className="d-flex flex-column align-items-center justify-content-center py-5 text-muted">
                <i className="ti ti-users-off fs-1 mb-2" />
                <p className="mb-0">No candidates uploaded for this exam yet.</p>
              </div>
            )}
            {!loadingCandidates && !candidatesError && candidates.length > 0 && (
              <>
                <div className="table-responsive">
                  <table className="table table-hover table-striped mb-0">
                    <thead className="table-light">
                      <tr>
                        <th style={{ width: 50 }}>#</th>
                        <th>Roll No</th>
                        <th>Name</th>
                        <th>Mobile</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pagedCandidates.length > 0 ? (
                        pagedCandidates.map((c, idx) => (
                          <tr key={c.roll_no || idx}>
                            <td className="text-muted">
                              {(currentPage - 1) * rowsPerPage + idx + 1}
                            </td>
                            <td>
                              <span className="  text-dark ">
                                {c.roll_no}
                              </span>
                            </td>
                            <td>{c.name}</td>
                            <td>{c.mobile}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={4} className="text-center text-muted py-4">
                            No results match your search.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
                {totalPages > 1 && (
                  <div className="d-flex align-items-center justify-content-between px-3 py-2 border-top flex-wrap gap-2">
                    <small className="text-muted">
                      Showing{" "}
                      {Math.min((currentPage - 1) * rowsPerPage + 1, filteredCandidates.length)}
                      –{Math.min(currentPage * rowsPerPage, filteredCandidates.length)} of{" "}
                      {filteredCandidates.length} candidates
                    </small>
                    <nav>
                      <ul className="pagination pagination-sm mb-0">
                        <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
                          <button
                            className="page-link"
                            onClick={() => setCurrentPage((p) => p - 1)}
                          >
                            &laquo;
                          </button>
                        </li>
                        {Array.from({ length: totalPages }, (_, i) => i + 1)
                          .filter(
                            (p) =>
                              p === 1 ||
                              p === totalPages ||
                              Math.abs(p - currentPage) <= 2
                          )
                          .reduce<(number | "…")[]>((acc, p, i, arr) => {
                            if (i > 0 && (p as number) - (arr[i - 1] as number) > 1)
                              acc.push("…")
                            acc.push(p)
                            return acc
                          }, [])
                          .map((p, i) =>
                            p === "…" ? (
                              <li key={`ellipsis-${i}`} className="page-item disabled">
                                <span className="page-link">…</span>
                              </li>
                            ) : (
                              <li
                                key={p}
                                className={`page-item ${currentPage === p ? "active" : ""}`}
                              >
                                <button
                                  className="page-link"
                                  onClick={() => setCurrentPage(p as number)}
                                >
                                  {p}
                                </button>
                              </li>
                            )
                          )}
                        <li className={`page-item ${currentPage === totalPages ? "disabled" : ""}`}>
                          <button
                            className="page-link"
                            onClick={() => setCurrentPage((p) => p + 1)}
                          >
                            &raquo;
                          </button>
                        </li>
                      </ul>
                    </nav>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}
      {showConfirm && (
        <div
          className="modal fade show d-block"
          style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
          tabIndex={-1}
        >
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">

              <div className="modal-header border-bottom-0 pb-0">
                <div className="d-flex align-items-center gap-2">
                  
                  <h5 className="modal-title mb-0">Replace Existing Candidates?</h5>
                </div>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowConfirm(false)}
                />
              </div>

              <div className="modal-body pt-2">
                <p className="text-muted mb-2">
                  This exam already has{" "}
                  <strong className="text-dark">{candidates.length} candidate{candidates.length !== 1 ? "s" : ""}</strong>{" "}
                  on record.
                </p>
                <p className="mb-2">
                  Uploading the new file will <strong>permanently remove</strong> all existing
                  candidates and replace them with the records from{" "}
                  <strong>{file?.name}</strong>.
                </p>
                <div className="alert alert-warning py-2 mb-0 small">
                  <strong>Note:</strong> This action cannot be undone. Please ensure
                  the new file contains all intended candidates — including any you
                  wish to retain from the previous upload.
                </div>
              </div>

              <div className="modal-footer border-top-0 pt-0">
                <button
                  type="button"
                  className="btn btn-outline-secondary"
                  onClick={() => setShowConfirm(false)}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className="btn btn-warning"
                  onClick={doUpload}
                >
                  Yes, Replace All Candidates
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

    </>
  )
}