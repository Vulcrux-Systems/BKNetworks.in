"use client";

import Link from "next/link";
import { useState, useEffect } from "react";

const categories = [
  {
    title: "Exam Management Modules",
    icon: "bi bi-grid-3x3-gap-fill",
    modules: [
      { path: "/exam-objections-admin/add-exam", label: "Manage Exams" },
      { path: "/exam-objections-admin/add-questions", label: "Manage Questions" },
      { path: "/exam-objections-admin/exam_candidates", label: "Manage Candidates" },
      { path: "/exam-objections-admin/view-objections", label: "View Objections/Cross Objections" },
    ]
  }
];


export default function JOAdminDashboard() {
  const [search, setSearch] = useState("");

  return (
    <div className="page-wrapper bg-light min-vh-100">
      <div className="page-inner p-4">
        {/* Page Header */}
        <div className="page-header mb-5 d-flex justify-content-between align-items-center">
          <div>
            <h1 className="display-6 fw-bold text-dark mb-1">Admin Dashboard</h1>
            <p className="text-muted mb-0">Exam Management Portal</p>
          </div>
          <div className="search-wrapper shadow-sm rounded-pill bg-white px-3 py-2 d-flex align-items-center" style={{ width: '350px' }}>
            <i className="bi bi-search text-primary me-2"></i>
            <input
              type="text"
              className="form-control border-0 bg-transparent shadow-none"
              placeholder="Search functions..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <div className="container-fluid">
          {categories.map((cat, cIdx) => {
            const catModules = cat.modules.filter(m => 
              m.label.toLowerCase().includes(search.toLowerCase())
            );
            
            if (catModules.length === 0) return null;

            return (
              <div key={cIdx} className="mb-5">
                <div className="d-flex align-items-center mb-3">
                  <div className="category-icon-wrapper bg-primary text-white p-2 rounded-3 me-3">
                    <i className={`${cat.icon} fs-5`}></i>
                  </div>
                  <h4 className="fw-bold text-secondary mb-0">{cat.title}</h4>
                  <div className="flex-grow-1 ms-3 border-bottom opacity-25"></div>
                </div>
                
                <div className="row g-3">
                  {catModules.map((module, mIdx) => (
                    <div key={mIdx} className="col-lg-3 col-md-4 col-sm-6">
                      <Link href={module.path} className="text-decoration-none">
                        <div className="module-card card h-100 border-0 shadow-sm transition-all">
                          <div className="card-body d-flex flex-column justify-content-center p-3">
                            <h6 className="card-title fw-bold text-dark mb-2">{module.label}</h6>
                            <div className="d-flex align-items-center text-primary small mt-auto">
                              <span>Open Module</span>
                              <i className="bi bi-arrow-right-short ms-1"></i>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {search && categories.every(c => c.modules.filter(m => m.label.toLowerCase().includes(search.toLowerCase())).length === 0) && (
            <div className="text-center py-5">
              <i className="bi bi-search text-muted display-4 mb-3 d-block"></i>
              <h5 className="text-muted">No functions match your search "{search}"</h5>
              <button className="btn btn-link py-0" onClick={() => setSearch("")}>Clear Search</button>
            </div>
          )}
        </div>
      </div>

      <style jsx>{`
        .module-card {
          border-left: 3px solid transparent !important;
          transition: all 0.25s ease-in-out;
        }
        .module-card:hover {
          transform: translateY(-5px);
          border-left-color: #0d6efd !important;
          box-shadow: 0 10px 20px rgba(0,0,0,0.08) !important;
        }
        .category-icon-wrapper {
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .transition-all {
          transition: all 0.2s ease-in-out;
        }
        .bg-light { background-color: #f8fafc !important; }
      `}</style>
    </div>
  );
}
