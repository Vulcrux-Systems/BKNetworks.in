import { NextRequest, NextResponse } from 'next/server'


const BASE_URL =
  process.env.NEXT_PUBLIC_BACKEND_CIS_API_URL ||
  process.env.NEXT_PUBLIC_BACKEND_MASTERS_API_URL ||
  ""
export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()

    const exam_id  = formData.get('exam_id')
    const username = formData.get('username')
    const file     = formData.get('file') as File

    if (!exam_id || !file) {
      return NextResponse.json(
        { error: 'exam_id and file are required' },
        { status: 400 }
      )
    }

    const backendForm = new FormData()
    backendForm.append('file', file)

    const response = await fetch(
      `${BASE_URL}/exam_objection/upload_candidates?exam_id=${exam_id}&username=${username}`,
      {
        method: 'POST',
        body: backendForm,
      }
    )

    const data = await response.json()

    if (!response.ok) {
      return NextResponse.json(
        { error: data.detail || 'Upload failed' },
        { status: response.status }
      )
    }

    return NextResponse.json(data)

  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}