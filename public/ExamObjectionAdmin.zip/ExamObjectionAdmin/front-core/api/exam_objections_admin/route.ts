import { NextRequest, NextResponse } from 'next/server'

const BASE_URL =
  process.env.NEXT_PUBLIC_BACKEND_CIS_API_URL ||
  process.env.NEXT_PUBLIC_BACKEND_MASTERS_API_URL ||
  ""

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const filename = searchParams.get('filename')

    if (!filename) {
      return NextResponse.json({ error: 'filename is required' }, { status: 400 })
    }

    const backendUrl = `${BASE_URL}/exam_objection/fetchDocs?filename=${encodeURIComponent(filename)}`
    const response = await fetch(backendUrl)

    if (!response.ok) {
      const text = await response.text()
      return NextResponse.json({ error: text }, { status: response.status })
    }

    const arrayBuffer = await response.arrayBuffer()  // ← more reliable than blob()

    return new NextResponse(arrayBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${filename}"`,  // inline = open in browser
        'Content-Length': arrayBuffer.byteLength.toString(),
      },
    })

  } catch (error) {
    console.error("Proxy error:", error)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}